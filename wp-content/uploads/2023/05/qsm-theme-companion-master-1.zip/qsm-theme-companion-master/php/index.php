<?php
// Silence is golden

