(function ($) {

	jQuery(document).ready(function () {		
		jQuery('#qsm_question_text_message_id').trigger('change');
	});
	

}(jQuery));